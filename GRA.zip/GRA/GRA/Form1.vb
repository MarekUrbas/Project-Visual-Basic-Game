﻿Public Class Form1
    Dim czas As Integer = 0
    Dim aktywny As String = "zolty"
    Dim punkty As Integer = 0
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        czas = czas + 1
        lblCzas.Text = "Czas: " + Convert.ToString(czas) + " Punkty: " + Convert.ToString(punkty)
        zmiana_koloru()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        klik("zolty")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        klik("niebieski")
    End Sub

    Private Sub klik(kolor As String)
        If aktywny = kolor Then
            If Timer1.Enabled = True Then
                punkty = punkty + 1
                lblCzas.Text = "Czas: " + Convert.ToString(czas) + " Punkty: " + Convert.ToString(punkty)
                zmiana_koloru()
                If punkty = 20 Then
                    Timer1.Enabled = False
                End If
            End If
        End If
    End Sub

    Private Sub zmiana_koloru()
        If aktywny = "zolty" Then
            aktywny = "niebieski"
            Button1.BackColor = Color.Gray
            Button2.BackColor = Color.LightSkyBlue
        Else
            aktywny = "zolty"
            Button1.BackColor = Color.Yellow
            Button2.BackColor = Color.Gray
        End If
    End Sub
End Class
